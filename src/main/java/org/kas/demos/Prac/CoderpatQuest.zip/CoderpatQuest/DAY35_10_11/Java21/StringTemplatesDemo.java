package org.kas.demos.Prac.CoderpatQuest.DAY35_10_11.Java21;

public class StringTemplatesDemo {
    public static void main(String[] args) {
        String name = "World";
        String message = STR."Hello, \{name}!"; // Using STR template processor
        System.out.println(message);
    }
}