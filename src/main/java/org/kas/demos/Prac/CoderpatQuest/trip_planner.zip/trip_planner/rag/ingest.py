from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader, PyPDFLoader
from trip_planner.rag.factory import RAGConnectorFactory

def ingest_files(file_paths, connector_type="pinecone", index_name="travel-knowledge"):
    """Load, split, and push files into vector DB"""
    connector = RAGConnectorFactory.create(connector_type, index_name=index_name)

    docs = []
    for path in file_paths:
        if path.endswith(".txt"):
            loader = TextLoader(path)
        elif path.endswith(".pdf"):
            loader = PyPDFLoader(path)
        else:
            raise ValueError(f"Unsupported file type: {path}")

        docs.extend(loader.load())

    splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    chunks = splitter.split_documents(docs)

    connector.ingest_documents(chunks)
    print(f"✅ Ingested {len(chunks)} chunks into {connector_type}:{index_name}")
