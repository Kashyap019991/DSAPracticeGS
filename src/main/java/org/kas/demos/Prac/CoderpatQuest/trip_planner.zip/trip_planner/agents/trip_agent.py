# trip_agent.py
from typing import TypedDict, Optional, List, Dict
import logging

# Import your existing agents
from trip_planner.agents import flight_agent, hotel_agent
from trip_planner.rag.factory import RAGConnectorFactory
from langchain_openai import ChatOpenAI
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate

# ---------------- Setup logger ---------------- #
logger = logging.getLogger("trip_agent")
logging.basicConfig(level=logging.INFO)

# ---------------- Shared State ---------------- #
class TravelState(TypedDict):
    origin: str
    destination: str
    date: str
    checkin: str
    checkout: str
    flights: Optional[List[Dict]]
    hotels: Optional[List[Dict]]
    knowledge: Optional[List[Dict]]
    suggestions: Optional[Dict]

# ---------------- RAG Setup ---------------- #
index_name = "travel-knowledge"
connector = RAGConnectorFactory.create("pinecone", index_name=index_name)
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

prompt_template = """
You are a travel assistant. Use ONLY the context provided to answer the question.
Format the answer clearly for a user, using bullet points if needed.
If the answer is not in the context, say "Sorry, I don't have information about this."

Context:
{context}

Question:
{question}

Answer:
"""
prompt = PromptTemplate(input_variables=["context", "question"], template=prompt_template)

# ---------------- Helper Functions ---------------- #
def normalize_airline_name(airline: str) -> str:
    """Normalize airline name to match Pinecone metadata."""
    if not airline:
        return ""
    airline = airline.lower()
    if "british" in airline or "ba" in airline:
        return "British"
    elif "emirates" in airline:
        return "Emirates"
    elif "qatar" in airline:
        return "Qatar"
    return airline.capitalize()

def rag_query(question: str, filters: Optional[Dict] = None) -> Dict:
    """Synchronous RAG query with friendly fallback."""
    try:
        retriever = connector.get_retriever(search_kwargs={"k": 3, "filter": filters or {}})
        rag_chain = RetrievalQA.from_chain_type(
            llm=llm,
            retriever=retriever,
            chain_type="stuff",
            chain_type_kwargs={"prompt": prompt},
            return_source_documents=True
        )
        result = rag_chain.invoke(question)

        # If no documents retrieved, fallback
        if not result.get("source_documents"):
            return {"result": "", "sources": []}

        sources = list({doc.metadata.get("source", "unknown") for doc in result["source_documents"]})
        return {"result": result["result"], "sources": sources}

    except Exception as e:
        logger.error(f"[RAG] Query failed: {e}")
        return {"result": "", "sources": []}

# ---------------- Node Functions ---------------- #
def flight_node(state: TravelState) -> TravelState:
    logger.info(f"[Node] flight_node: {state['origin']} → {state['destination']} on {state['date']}")
    state["flights"] = flight_agent.run_agent(state["origin"], state["destination"], state["date"])
    return state

def hotel_node(state: TravelState) -> TravelState:
    logger.info(f"[Node] hotel_node: searching hotels at {state['destination']}")
    state["hotels"] = hotel_agent.run_agent(state["destination"], state["checkin"], state["checkout"])
    return state

def rag_node(state: TravelState) -> TravelState:
    flights_data = state.get("flights") or {}
    flights_list = []

    if isinstance(flights_data, dict):
        flights_list = flights_data.get("flights", [])
    elif isinstance(flights_data, list):
        flights_list = flights_data

    logger.info(f"First flight returned: {flights_list[0] if flights_list else 'No flights'}")

    # If no flights, skip RAG
    if not flights_list:
        logger.warning("No flights found — skipping RAG query.")
        return state

    # Extract airline from first flight
    airline = normalize_airline_name(flights_list[0].get("airline"))
    logger.info(f"airline selected: {airline}")

    # Prepare filters
    filters = {"airline": airline} if airline else {}

    # RAG query
    state["knowledge"] = state.get("knowledge", [])
    result = rag_query(
        f"What is {airline} baggage and rescheduling policy?",
        filters=filters
    )

    # Friendly fallback
    result_text = result["result"] if result["result"] else f"Sorry, I don't have information about {airline} baggage policy at the moment."

    state["knowledge"].append({
        "type": "airline_policy",
        "result": result_text,
        "sources": result["sources"]
    })

    return state


# ---------------- Runner ---------------- #
def run_trip_agent(state: TravelState) -> TravelState:
    """Sequential execution of nodes"""
    try:
        state = flight_node(state)
        state = hotel_node(state)
        state = rag_node(state)
        return state
    except Exception as e:
        logger.error(f"[TripAgent] run_agent failed: {str(e)}", exc_info=True)
        raise
