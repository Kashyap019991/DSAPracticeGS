# ingest_docs.py
import os
from dotenv import load_dotenv
from glob import glob
from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from trip_planner.rag.factory import RAGConnectorFactory
from pinecone import Pinecone, ServerlessSpec

# ---------------- Load environment variables ---------------- #
load_dotenv()
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_ENV = os.getenv("PINECONE_ENV", "aws")  # default to aws
INDEX_NAME = "travel-knowledge"

# ---------------- Connect to Pinecone ---------------- #
pc = Pinecone(api_key=PINECONE_API_KEY)

# Delete existing index if exists
if INDEX_NAME in pc.list_indexes().names():
    print(f"Deleting existing index '{INDEX_NAME}'...")
    pc.delete_index(INDEX_NAME)

# Create new index
print(f"Creating new index '{INDEX_NAME}'...")
pc.create_index(
    name=INDEX_NAME,
    dimension=1536,  # make sure this matches your embeddings
    metric="cosine",
    spec=ServerlessSpec(cloud=PINECONE_ENV, region="us-east-1")  # adjust region if needed
)

# Connect via your RAG connector
connector = RAGConnectorFactory.create("pinecone", index_name=INDEX_NAME)

# ---------------- Text Splitter ---------------- #
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=800,
    chunk_overlap=100,
)

# ---------------- Load Data ---------------- #
DATA_FOLDER = os.path.join(os.path.dirname(__file__), "data")
txt_files = glob(os.path.join(DATA_FOLDER, "*.txt"))

all_documents = []

for file_path in txt_files:
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    # Split text into chunks
    chunks = text_splitter.split_text(content)
    
    # Metadata based on filename
    filename = os.path.basename(file_path)
    metadata = {"source": filename}
    
    airlines = ["emirates", "qatar", "british_airways", "british", "ba"]
    hotels = ["hilton", "marriott"]
    filename_lower = filename.lower()

    if any(a in filename_lower for a in airlines):
        metadata["type"] = "airline_policy"
        metadata["airline"] = filename.split("_")[0].capitalize()
    elif any(h in filename_lower for h in hotels):
        metadata["type"] = "hotel_policy"
        metadata["hotel"] = filename.split("_")[0].capitalize()
    else:
        metadata["type"] = "travel_guide"
        metadata["location"] = filename.split("_")[0].capitalize()
    
    # Create Document objects
    for chunk in chunks:
        doc = Document(page_content=chunk, metadata=metadata)
        all_documents.append(doc)

# ---------------- Ingest into Pinecone ---------------- #
connector.ingest_documents(all_documents)
print(f"✅ Ingested {len(all_documents)} documents into Pinecone index '{INDEX_NAME}'")
