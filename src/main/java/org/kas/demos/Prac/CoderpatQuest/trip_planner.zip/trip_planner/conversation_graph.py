# trip_planner/conversation_graph.py
from langgraph.graph import StateGraph
from trip_planner.conversation_nodes import conversation_node
from trip_planner.conversation_state import ConversationState

def build_conversation_graph():
    workflow = StateGraph(ConversationState)
    workflow.add_node("conversation_node", conversation_node)
    workflow.set_entry_point("conversation_node")
    return workflow.compile()
