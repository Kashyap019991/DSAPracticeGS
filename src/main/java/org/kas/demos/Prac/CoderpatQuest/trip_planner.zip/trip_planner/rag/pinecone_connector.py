from typing import List
from langchain.schema import Document
from langchain_openai import OpenAIEmbeddings
from langchain_pinecone import PineconeVectorStore
from pinecone import Pinecone, ServerlessSpec
import os

from trip_planner.rag.base import BaseRAGConnector


class PineconeRAGConnector(BaseRAGConnector):
    def __init__(self, index_name: str = "travel-knowledge"):
        api_key = os.getenv("PINECONE_API_KEY")
        if not api_key:
            raise ValueError("PINECONE_API_KEY not found in environment")

        self.index_name = index_name
        self.embeddings = OpenAIEmbeddings()

        # Create Pinecone client
        self.pc = Pinecone(api_key=api_key)

        # Ensure index exists (auto-create if missing)
        existing_indexes = self.pc.list_indexes().names()
        if self.index_name not in existing_indexes:
            self.pc.create_index(
                name=self.index_name,
                dimension=1536,  # OpenAI embeddings dimension
                metric="cosine",
                spec=ServerlessSpec(cloud="aws", region="us-west-2"),
            )

        # Create vectorstore
        self.vectorstore = PineconeVectorStore(
            index=self.pc.Index(self.index_name),
            embedding=self.embeddings,
            text_key="text",
        )

    def get_vectorstore(self):
        return self.vectorstore

    def get_retriever(self, **kwargs):
        return self.vectorstore.as_retriever(**kwargs)

    def ingest_documents(self, docs: List[Document]):
        """Add docs into Pinecone index"""
        self.vectorstore.add_documents(docs)
