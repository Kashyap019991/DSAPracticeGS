# trip_planner/conversation_state.py
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

class ConversationState(BaseModel):
    origin: Optional[str] = None
    destinations: List[str] = []
    travel_date: Optional[str] = None 
    checkin: Optional[str] = None
    checkout: Optional[str] = None
    chat_history: List[Dict[str, str]] = []
    suggestions: Dict[str, Any] = {}
    user_input: Optional[str] = None
    step: str = "ask_origin"  # track workflow step
