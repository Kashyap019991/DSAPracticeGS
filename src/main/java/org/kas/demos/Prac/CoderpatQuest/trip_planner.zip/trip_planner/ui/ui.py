# ui_resilient_fallback.py
import streamlit as st
import requests
import pandas as pd
import logging

# ----- Logging setup -----
logging.basicConfig(
    filename="trip_planner_ui.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

API_URL = "http://127.0.0.1:8000/trip-recommendations"

st.set_page_config(page_title="Trip Planner", page_icon="✈️", layout="centered")
st.title("✈️ Trip Planner Assistant")
st.write("Get personalized flight, hotel, and travel recommendations")

# ----- User Input Form -----
with st.form("trip_form"):
    origin = st.text_input("Origin", "New York")
    destination = st.text_input("Destination", "London")
    date = st.date_input("Flight Date")
    checkin = st.date_input("Hotel Check-in")
    checkout = st.date_input("Hotel Check-out")
    
    submitted = st.form_submit_button("Get Recommendations")

if submitted:
    payload = {
        "origin": origin,
        "destination": destination,
        "date": str(date),
        "checkin": str(checkin),
        "checkout": str(checkout),
    }
    logger.info(f"Submitting payload: {payload}")

    with st.spinner("Fetching trip recommendations..."):
        try:
            response = requests.post(API_URL, json=payload)
            response.raise_for_status()
            data = response.json()
            logger.debug(f"API response JSON: {data}")

            recs = data.get("recommendations", {})

            # ---- Flights ----
            st.subheader("🛫 Flight Options")
            flights_container = recs.get("flights", {})
            flights = []
            if isinstance(flights_container, dict):
                flights = flights_container.get("flights", [])
            elif isinstance(flights_container, list):
                flights = flights_container

            if flights:
                for f in flights:
                    if isinstance(f, dict):
                        st.markdown(
                            f"**{f.get('airline','N/A')}**\n"
                            f"- flight_number: {f.get('flight_number','N/A')}\n"
                            f"- date: {f.get('date','N/A')}\n"
                            f"- Price: {f.get('price','N/A')}"
                        )
                    else:
                        st.markdown(f"- {f}")
                    st.markdown("---")
            else:
                st.info("No flight options available.")

            # ---- Hotels ----
            st.subheader("🏨 Hotel Options")
            hotels_container = recs.get("hotels", {})
            hotels = []
            if isinstance(hotels_container, dict):
                hotels = hotels_container.get("hotels", [])
            elif isinstance(hotels_container, list):
                hotels = hotels_container

            if hotels:
                if isinstance(hotels[0], dict):
                    st.dataframe(pd.DataFrame(hotels))
                else:
                    for h in hotels:
                        st.markdown(f"- {h}")
            else:
                st.info("No hotel options available.")

            # ---- Knowledge / Travel Guide ----
            st.subheader("📖 Travel Guide / Knowledge")
            knowledge = recs.get("knowledge", None)

            def render_knowledge(k):
                """Render knowledge gracefully for any type"""
                if isinstance(k, dict):
                    st.markdown(f"**Type:** {k.get('type','N/A')}")
                    st.markdown(f"**Result:** {k.get('result','N/A')}")
                    sources = k.get("sources", [])
                    if sources:
                        st.markdown("**Sources:**")
                        for s in sources:
                            st.markdown(f"- {s}")
                    else:
                        st.markdown("_No sources available_")
                elif isinstance(k, list):
                    for item in k:
                        render_knowledge(item)  # recursive for nested lists
                elif isinstance(k, str):
                    st.markdown(k)
                else:
                    st.markdown(str(k))

            if knowledge:
                render_knowledge(knowledge)
            else:
                st.info("No travel guide information available.")

            st.success(f"✅ Results fetched in {data.get('search_time', 'N/A')} seconds")

        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            st.error(f"API call failed: {e}")
        except Exception as e:
            logger.exception(f"Unexpected error: {e}")
            st.error(f"An unexpected error occurred: {e}")