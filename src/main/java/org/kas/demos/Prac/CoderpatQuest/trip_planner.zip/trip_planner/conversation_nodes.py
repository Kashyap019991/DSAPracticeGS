# trip_planner/conversation_nodes.py
from trip_planner.conversation_state import ConversationState

def conversation_node(state: ConversationState) -> ConversationState:
    """
    Handles the conversational trip planning flow:
    1️⃣ Ask origin
    2️⃣ Ask destination
    3️⃣ Ask travel date
    4️⃣ Ask hotel check-in/check-out
    5️⃣ Confirm trip
    """
    user_input = state.user_input

    # 1️⃣ Ask for origin
    if state.step in [None, "ask_origin"] and not state.origin:
        if user_input and user_input != "__start_conversation__":
            state.origin = user_input
            state.chat_history.append({
                "role": "assistant",
                "message": f"Got it! You're traveling from {state.origin}. Where would you like to go?"
            })
            state.step = "ask_destination"
            state.user_input = None  # reset after processing
            return state
        else:
            state.chat_history.append({
                "role": "assistant",
                "message": "Hello! Where are you traveling from?"
            })
            state.step = "ask_origin"
            return state

    # 2️⃣ Ask for destination
    if state.step == "ask_destination" and not state.destinations:
        if user_input:
            state.destinations = [user_input]
            state.chat_history.append({
                "role": "assistant",
                "message": f"Great! Traveling to {', '.join(state.destinations)}. When do you want to travel?"
            })
            state.step = "ask_date"
            state.user_input = None
            return state
        else:
            state.chat_history.append({
                "role": "assistant",
                "message": "Where would you like to go?"
            })
            return state

    # 3️⃣ Ask for travel date
    if state.step == "ask_date" and not getattr(state, "travel_date", None):
        if user_input:
            state.travel_date = user_input
            state.chat_history.append({
                "role": "assistant",
                "message": "Do you have hotel check-in and check-out dates?"
            })
            state.step = "ask_hotel_dates"
            state.user_input = None
            return state
        else:
            state.chat_history.append({
                "role": "assistant",
                "message": "When do you want to travel?"
            })
            return state

    # 4️⃣ Ask for hotel check-in/check-out
    if state.step == "ask_hotel_dates" and (not getattr(state, "checkin", None) or not getattr(state, "checkout", None)):
        if user_input:
            # Here we could parse a single message into checkin/checkout if desired
            # For simplicity, assume user inputs "YYYY-MM-DD to YYYY-MM-DD"
            try:
                dates = user_input.split("to")
                state.checkin = dates[0].strip()
                state.checkout = dates[1].strip()
            except Exception:
                state.chat_history.append({
                    "role": "assistant",
                    "message": "Please provide hotel check-in and check-out dates in format: YYYY-MM-DD to YYYY-MM-DD"
                })
                return state

            state.chat_history.append({
                "role": "assistant",
                "message": (
                    f"Perfect! Planning your trip from {state.origin} "
                    f"to {', '.join(state.destinations)} on {state.travel_date}, "
                    f"with hotel from {state.checkin} to {state.checkout}."
                )
            })
            state.step = "completed"
            state.user_input = None
            return state
        else:
            state.chat_history.append({
                "role": "assistant",
                "message": "Do you have hotel check-in and check-out dates?"
            })
            return state

    # 5️⃣ Completed
    if state.step == "completed":
        state.chat_history.append({
            "role": "assistant",
            "message": "Your trip plan is complete! You can start a new trip or modify details."
        })

    return state
