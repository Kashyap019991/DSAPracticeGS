from typing import Dict, Any, List
import logging
from trip_planner.agents import flight_agent, hotel_agent
from trip_planner.rag.factory import RAGConnectorFactory
from langchain_openai import ChatOpenAI
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from typing import TypedDict, Optional, Dict, Any, List

class MCPTripQuery(TypedDict):
    origin: str
    destination: str
    date: str
    checkin: str
    checkout: str
    flights: Optional[List[Dict[str, Any]]]
    hotels: Optional[List[Dict[str, Any]]]
    knowledge: Optional[Any]
    mcp_logs: Optional[List[Dict[str, Any]]]
    
logger = logging.getLogger("mcp_trip_agent")
logging.basicConfig(level=logging.INFO)

# ---------------- MCP Wrapper ---------------- #
class MCPAgent:
    def __init__(self, model_name: str, model_version: str, agent_func):
        self.model_name = model_name
        self.model_version = model_version
        self.agent_func = agent_func

    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Run agent and log inputs/outputs in MCP format"""
        logger.info(f"[MCP] Running {self.model_name} v{self.model_version}")
        try:
            output = self.agent_func(input_data)
            result = {
                "model_name": self.model_name,
                "model_version": self.model_version,
                "input": input_data,
                "output": output,
            }
            logger.info(f"[MCP] Output: {output}")
            return result
        except Exception as e:
            logger.error(f"[MCP] {self.model_name} failed: {str(e)}", exc_info=True)
            return {
                "model_name": self.model_name,
                "model_version": self.model_version,
                "input": input_data,
                "output": None,
                "error": str(e)
            }
            
# ---------------- RAG Setup ---------------- #
index_name = "travel-knowledge"
connector = RAGConnectorFactory.create("pinecone", index_name=index_name)
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

prompt_template = """You are a travel assistant. Use ONLY the context provided to answer the question.
If the answer is not in the context, say "I don't know".

Context:
{context}

Question:
{question}

Answer:"""

prompt = PromptTemplate(input_variables=["context", "question"], template=prompt_template)
def rag_agent_func(state: Dict[str, Any]) -> Dict[str, Any]:
    retriever = connector.get_retriever(search_kwargs={"k": 3})
    rag_chain = RetrievalQA.from_chain_type(
        llm=llm,
        retriever=retriever,
        chain_type="stuff",
        chain_type_kwargs={"prompt": prompt},
        return_source_documents=True,
    )
    question = f"Provide a travel guide for {state['destination']}"
    result = rag_chain.invoke(question)
    return result

# ---------------- MCP-Enabled Trip Agent ---------------- #
class MCPTripAgent:
    def __init__(self):
        # Wrap each agent in MCP
        self.flight_agent = MCPAgent("flight_agent", "1.0", lambda s: flight_agent.run_agent(s["origin"], s["destination"], s["date"]))
        self.hotel_agent = MCPAgent("hotel_agent", "1.0", lambda s: hotel_agent.run_agent(s["destination"], s["checkin"], s["checkout"]))
        self.rag_agent = MCPAgent("rag_agent", "1.0", rag_agent_func)

    def run_trip(self, state: Dict[str, Any]) -> Dict[str, Any]:
        state = state.copy()
        state["mcp_logs"] = []

        # Flights
        flight_input = {k: v for k, v in state.items() if k != "mcp_logs"}
        flight_result = self.flight_agent.run(flight_input)
        state["mcp_logs"].append(flight_result)
        state["flights"] = flight_result["output"]

        # Hotels
        hotel_input = {k: v for k, v in state.items() if k != "mcp_logs"}
        hotel_result = self.hotel_agent.run(hotel_input)
        state["mcp_logs"].append(hotel_result)
        state["hotels"] = hotel_result["output"]

        # RAG Knowledge
        rag_input = {k: v for k, v in state.items() if k != "mcp_logs"}
        rag_result = self.rag_agent.run(rag_input)
        state["mcp_logs"].append(rag_result)
        state["knowledge"] = rag_result["output"]

        return state

