from typing import TypedDict, Optional
from langgraph.graph import StateGraph
from trip_planner.agents import flight_agent, hotel_agent
import logging
from datetime import datetime, timedelta
from langsmith import traceable


logger = logging.getLogger("orchestrator")
logging.basicConfig(level=logging.INFO)

# Shared state across agents
class TravelState(TypedDict):
    origin: str
    destination: str
    date: str
    flights: Optional[dict]
    hotels: Optional[dict]
    suggestions: Optional[dict]  # structured now
    
    # --- Agents ---
def flight_node(state: TravelState) -> TravelState:
    logger.info(f"Searching flights: {state['origin']} → {state['destination']} on {state['date']}")
    result = flight_agent.run_agent(state["origin"], state["destination"], state["date"])
    state["flights"] = result
    return state

def hotel_node(state: TravelState) -> TravelState:
    logger.info(f"Searching hotels at {state['destination']}")
    result = hotel_agent.run_agent(state["destination"], state["date"], state["date"])
    state["hotels"] = result
    return state

def suggest_alternative_dates(state: TravelState) -> TravelState:
    logger.warning(f"No flights found for {state['date']} — suggesting alternative dates")

    try:
        base_date = datetime.strptime(state["date"], "%Y-%m-%d")
    except ValueError:
        logger.error("Invalid date format, must be YYYY-MM-DD")
        state["suggestions"] = {"error": "Invalid date format"}
        return state

    alternatives = [
        (base_date - timedelta(days=1)).strftime("%Y-%m-%d"),
        (base_date + timedelta(days=1)).strftime("%Y-%m-%d"),
        (base_date + timedelta(days=2)).strftime("%Y-%m-%d")
    ]

    state["suggestions"] = {
        "message": f"No flights available on {state['date']}. Try nearby dates.",
        "alternative_dates": alternatives
    }
    return state
# --- Conditional Check ---
def has_flights(state: TravelState) -> str:
    """Return the next node depending on flight results"""
    flights = state.get("flights", {})
    if isinstance(flights, dict) and flights.get("flights"):
        return "hotel_agent"
    return "suggest_alternatives"

@traceable(name="Trip Orchestrator")
# --- Build Graph ---
def build_travel_graph():
    workflow = StateGraph(TravelState)

    workflow.add_node("flight_agent", flight_node)
    workflow.add_node("hotel_agent", hotel_node)
    workflow.add_node("suggest_alternatives", suggest_alternative_dates)

    workflow.set_entry_point("flight_agent")

    # Add conditional edge
    workflow.add_conditional_edges("flight_agent", has_flights)

    # Optional fallback chaining
    workflow.add_edge("hotel_agent", "suggest_alternatives")

    return workflow.compile()

