# trip_planner/agents/conversation_agents.py
import logging
from typing import Dict, Any, List
from trip_planner.agents import flight_agent, hotel_agent
from trip_planner.agents.trip_agent import rag_query, normalize_airline_name

logger = logging.getLogger("conversation_agents")
logging.basicConfig(level=logging.INFO)

class ConversationFlightAgent:
    @staticmethod
    def run(origin: str, destination: str, date: str) -> Dict[str, Any]:
        logger.info(f"[ConversationFlightAgent] {origin} -> {destination} on {date}")
        return flight_agent.run_agent(origin, destination, date)

class ConversationHotelAgent:
    @staticmethod
    def run(location: str, checkin: str, checkout: str) -> Dict[str, Any]:
        logger.info(f"[ConversationHotelAgent] {location} ({checkin} → {checkout})")
        return hotel_agent.run_agent(location, checkin, checkout)

class ConversationRAGAgent:
    @staticmethod
    def run(flights: List[Dict]) -> List[Dict[str, Any]]:
        knowledge = []
        if flights:
            airline = normalize_airline_name(flights[0].get("airline"))
            if airline:
                result = rag_query(f"What is {airline} baggage and rescheduling policy?")
                knowledge.append({"type": "airline_policy", "result": result["result"], "sources": result["sources"]})
        return knowledge