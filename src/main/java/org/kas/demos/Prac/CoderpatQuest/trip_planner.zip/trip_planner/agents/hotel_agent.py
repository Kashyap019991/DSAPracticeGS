import asyncio
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os

from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field
from typing import List
from langsmith import traceable

from trip_planner.logger import get_logger

logger = get_logger("hotel_agent")
executor = ThreadPoolExecutor()

# ---------------- Models ---------------- #
class Hotel(BaseModel):
    hotel_name: str = Field(description="Name of the hotel")
    price_per_night: float = Field(description="Price per night in USD")
    rating: float = Field(description="Hotel rating out of 5")

class HotelResponse(BaseModel):
    hotels: List[Hotel]

parser = PydanticOutputParser(pydantic_object=HotelResponse)

# ---------------- Load prompt ---------------- #
def load_prompt() -> str:
    prompt_path = Path(__file__).parent.parent / "prompts" / "hotel_prompts.md"
    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()

# ---------------- Lazy Initialization ---------------- #
def get_llm():
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        logger.error("❌ OPENAI_API_KEY is not set in environment.")
        raise RuntimeError("OPENAI_API_KEY missing")
    return ChatOpenAI(model="gpt-4o-mini", temperature=0, api_key=api_key)

@traceable(name="Hotel Agent Sync")
# ---------------- Synchronous call ---------------- #
def run_agent(location: str, checkin: str, checkout: str) -> dict:
    logger.info(f"Running hotel agent for {location} ({checkin} → {checkout})")

    base_prompt = load_prompt()
    prompt = PromptTemplate(
        input_variables=["location", "checkin", "checkout"],
        template=base_prompt + "\n\n{format_instructions}"
    )

    llm = get_llm()
    formatted_prompt = prompt.format(
        location=location,
        checkin=checkin,
        checkout=checkout,
        format_instructions=parser.get_format_instructions()
    )

    response = llm.invoke(formatted_prompt)

    try:
        result = parser.parse(response.content)
        logger.info("✅ Hotel agent parsed valid structured response.")
        return result.dict()
    except Exception as e:
        logger.warning(f"⚠️ Hotel agent returned invalid JSON: {e}")
        return {"raw_response": response.content}

@traceable(name="Hotel Agent Async")
# ---------------- Async wrapper ---------------- #
async def run_agent_async(location: str, checkin: str, checkout: str):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        executor, lambda: run_agent(location, checkin, checkout)
    )
