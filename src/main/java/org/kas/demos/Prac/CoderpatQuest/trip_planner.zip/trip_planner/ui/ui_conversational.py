# ui_conversational_trip.py
import streamlit as st
import requests
import logging
import pandas as pd

# ----- Logging setup -----
logging.basicConfig(
    filename="trip_planner_chat_ui.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

CHAT_API_URL = "http://127.0.0.1:8000/chat-trip"
REC_API_URL = "http://127.0.0.1:8000/trip-recommendations"

# ----- Streamlit page config -----
st.set_page_config(page_title="Trip Planner Chat", page_icon="✈️", layout="centered")
st.title("✈️ Conversational Trip Planner Assistant")

# ----- Session state initialization -----
if "conversation_state" not in st.session_state:
    st.session_state.conversation_state = None
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []


# ----- Initialize conversation -----
if st.session_state.conversation_state is None:
    payload = {"user_input": "__start_conversation__", "state": None}
    logger.info(f"Initializing conversation with payload: {payload}")
    try:
        response = requests.post(CHAT_API_URL, json=payload)
        response.raise_for_status()
        data = response.json()
        st.session_state.conversation_state = data.get("state", {})
        st.session_state.chat_history.extend(st.session_state.conversation_state.get("chat_history", []))
        logger.info("Conversation initialized successfully")
    except Exception as e:
        st.error(f"Failed to initialize conversation: {e}")
        logger.error(f"Conversation init failed: {e}")

# ----- Display chat history -----
for msg in st.session_state.chat_history:
    if msg["role"] == "user":
        st.markdown(f"**You:** {msg['message']}")
    else:
        st.markdown(f"**Assistant:** {msg['message']}")

# ----- User input -----
user_input = st.text_input(
    "Type your message here...",
    value="",
    key="input_text"
)

if st.button("Send") and user_input:

   # 1️⃣ Append user input
    st.session_state.chat_history.append({"role": "user", "message": user_input})

    # 2️⃣ Send to API
    payload = {
        "user_input": user_input,
        "state": st.session_state.conversation_state
    }

    logger.info(f"Sending payload to backend: {payload}")

    with st.spinner("Processing..."):
        try:
            # Call chat API
            response = requests.post(CHAT_API_URL, json=payload)
            response.raise_for_status()
            data = response.json()
            logger.debug(f"Chat API response JSON: {data}")

            # Update conversation state
            st.session_state.conversation_state = data.get("state", {})

             # 4️⃣ Append assistant messages immediately
            for msg in st.session_state.conversation_state.get("chat_history", []):
                key = (msg["role"], msg["message"])
                if key not in set((m["role"], m["message"]) for m in st.session_state.chat_history):
                    st.session_state.chat_history.append(msg)
                    
            # 5️⃣ Render chat
            for msg in st.session_state.chat_history:
                if msg["role"] == "user":
                    st.markdown(f"**You:** {msg['message']}")
                else:
                    st.markdown(f"**Assistant:** {msg['message']}")
                    
            # ----- Automatically fetch recommendations if step is completed -----
            if st.session_state.conversation_state.get("step") == "completed":
                rec_payload = {
                    "origin": st.session_state.conversation_state.get("origin"),
                    "destination": st.session_state.conversation_state.get("destinations")[0] if st.session_state.conversation_state.get("destinations") else "",
                    "date": st.session_state.conversation_state.get("travel_date"),
                    "location": st.session_state.conversation_state.get("destinations")[0] if st.session_state.conversation_state.get("destinations") else "",
                    "checkin": st.session_state.conversation_state.get("checkin"),
                    "checkout": st.session_state.conversation_state.get("checkout")
                }
                logger.info(f"Fetching trip recommendations with payload: {rec_payload}")

                with st.spinner("Fetching trip recommendations..."):
                    try:
                        rec_response = requests.post(REC_API_URL, json=rec_payload)
                        rec_response.raise_for_status()
                        rec_data = rec_response.json()
                        recs = rec_data.get("recommendations", {})

                        # ---- Flights ----
                        st.subheader("🛫 Flight Options")
                        flights_container = recs.get("flights", [])
                        if isinstance(flights_container, dict):
                            flights = flights_container.get("flights", [])
                        else:
                            flights = flights_container

                        if flights:
                            for f in flights:
                                if isinstance(f, dict):
                                    st.markdown(
                                        f"**{f.get('airline','N/A')}**\n"
                                        f"- Flight Number: {f.get('flight_number','N/A')}\n"
                                        f"- Date: {f.get('date','N/A')}\n"
                                        f"- Price: {f.get('price','N/A')}"
                                    )
                                else:
                                    st.markdown(f"- {f}")
                                st.markdown("---")
                        else:
                            st.info("No flight options available.")

                        # ---- Hotels ----
                        st.subheader("🏨 Hotel Options")
                        hotels_container = recs.get("hotels", [])
                        if isinstance(hotels_container, dict):
                            hotels = hotels_container.get("hotels", [])
                        else:
                            hotels = hotels_container

                        if hotels:
                            if isinstance(hotels[0], dict):
                                st.dataframe(pd.DataFrame(hotels))
                            else:
                                for h in hotels:
                                    st.markdown(f"- {h}")
                        else:
                            st.info("No hotel options available.")

                        # ---- Knowledge / Travel Guide ----
                        st.subheader("📖 Travel Guide / Knowledge")
                        knowledge = recs.get("knowledge", None)

                        def render_knowledge(k):
                            if isinstance(k, dict):
                                st.markdown(f"**Type:** {k.get('type','N/A')}")
                                st.markdown(f"**Result:** {k.get('result','N/A')}")
                                sources = k.get("sources", [])
                                if sources:
                                    st.markdown("**Sources:**")
                                    for s in sources:
                                        st.markdown(f"- {s}")
                                else:
                                    st.markdown("_No sources available_")
                            elif isinstance(k, list):
                                for item in k:
                                    render_knowledge(item)
                            elif isinstance(k, str):
                                st.markdown(k)
                            else:
                                st.markdown(str(k))

                        if knowledge:
                            render_knowledge(knowledge)
                        else:
                            st.info("No travel guide information available.")

                        st.success("✅ Recommendations fetched successfully")

                    except requests.exceptions.RequestException as e:
                        st.error(f"Recommendations API call failed: {e}")
                        logger.error(f"Recommendations API call failed: {e}")

        except requests.exceptions.RequestException as e:
            st.error(f"Chat API call failed: {e}")
            logger.error(f"Chat API call failed: {e}")
        except Exception as e:
            st.error(f"An unexpected error occurred: {e}")
            logger.exception(f"Unexpected error in chat flow: {e}")

# ----- Optional: Debug conversation state -----
with st.expander("Debug: Conversation State"):
    st.json(st.session_state.conversation_state)