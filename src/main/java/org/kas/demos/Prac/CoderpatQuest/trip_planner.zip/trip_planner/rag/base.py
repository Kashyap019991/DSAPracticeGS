from abc import ABC, abstractmethod
from typing import List
from langchain.schema import Document

class BaseRAGConnector(ABC):
    """Abstract base for all RAG vector store connectors."""

    @abstractmethod
    def get_vectorstore(self):
        """Return a vectorstore instance (LangChain compatible)."""
        pass

    @abstractmethod
    def get_retriever(self, **kwargs):
        """Return a retriever from the vectorstore."""
        pass

    @abstractmethod
    def ingest_documents(self, docs: List[Document]):
        """Add documents to the vector store."""
        pass