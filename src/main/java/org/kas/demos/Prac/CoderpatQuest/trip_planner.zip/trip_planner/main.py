from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import time
import asyncio
import os
from typing import Optional, Dict, Any
from trip_planner.rag.factory import RAGConnectorFactory
from trip_planner.conversation_state import ConversationState
from pinecone import Pinecone, ServerlessSpec

from langchain_openai import ChatOpenAI
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate

from trip_planner.orchestrator import build_travel_graph, TravelState
from trip_planner.logger import get_logger
from trip_planner.agents.flight_agent import run_agent_async, FlightResult as AgentFlightResult 
from trip_planner.agents import hotel_agent,flight_agent,trip_agent

from trip_planner.agents.mcp_trip_agent import MCPTripAgent, MCPTripQuery
from trip_planner.conversation_graph import build_conversation_graph

from trip_planner.conversation_state import ConversationState


mcp_agent = MCPTripAgent()


app = FastAPI(title="Flight Search", version="0.1")
logger = get_logger("main")

# --------------------
# Models
# --------------------
class FlightQuery(BaseModel):
    origin: str
    destination: str
    date: str  # simple string for now, e.g. "2025-09-20"
class HotelQuery(BaseModel):
    location: str
    checkin: str
    checkout: str
class PlanTripQuery(BaseModel):
    origin: str
    destination: str
    date: str
    location: str
    checkin: str
    checkout: str
    
class RagQuery(BaseModel):
    question: str 

class TripRecommendationsQuery(BaseModel):
    origin: str
    destination: str
    date: str
    location: str
    checkin: str
    checkout: str

# ---------------- Models ---------------- #
class TripQuery(BaseModel):
    origin: str
    destination: str
    date: str
    checkin: str
    checkout: str
    
class MCPTripQuery(BaseModel):
    origin: str
    destination: str
    date: str
    checkin: str
    checkout: str
class ChatTripQuery(BaseModel):
    user_input: str
    state: Optional[Dict[str, Any]] = None
# ---------------- Build orchestrator ---------------- #
workflow = build_travel_graph()
# new conversation workflow
conversation_workflow = build_conversation_graph()
# --------------------
# Endpoints
# --------------------
@app.get("/health")
async def health():
    return {"status": "ok"}

# ---------------- Lifecycle Events ---------------- #
@app.on_event("startup")
async def startup_event():
    logger.info("🚀 FastAPI application started.")

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("🛑 FastAPI application stopped.")

# ---------------- Flight Search API ---------------- #
@app.post("/flight-search")
async def flight_search(query: FlightQuery):
    logger.info(f"Received flight search request: {query}")

    try:
        start_time = time.time()
        # Call the agent (async)
        result: AgentFlightResult = await run_agent_async(query.origin, query.destination, query.date)
        duration = time.time() - start_time

        logger.info(f"✅ Flight agent response received in {duration:.2f}s")
        return {
            "query": query,
            "results": result.flights,
            "search_time": f"{duration:.2f}s",
        }
    except Exception as e:
        logger.error(f"❌ Flight search failed: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Flight search failed")
    
# ---------------- Hotel Search API ---------------- # 
@app.post("/hotel-search")
async def hotel_search(query: HotelQuery):
    logger.info(f"Received hotel search request: {query}")
    try:
        start_time = time.time()
        
        # add timeout in case LLM hangs
        result = await asyncio.wait_for(
            hotel_agent.run_agent_async(query.location, query.checkin, query.checkout),
            timeout=20  # seconds
        )
        
        duration = time.time() - start_time
        logger.info(f"✅ Hotel agent response received in {duration:.2f}s")

        # If result is a Pydantic model
        if hasattr(result, "dict"):
            result = result.dict()

        return {
            "query": query,
            "results": result,
            "search_time": f"{duration:.2f}s",
        }

    except asyncio.TimeoutError:
        logger.error("⏰ Hotel agent timed out.")
        raise HTTPException(status_code=504, detail="Hotel search timed out")
    except Exception as e:
        logger.error(f"❌ Hotel search failed: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Hotel search failed")

# ---------------- Orchestrated Trip Planning API ---------------- #
@app.post("/plan-trip")
async def plan_trip(query: PlanTripQuery):
    logger.info(f"🗺️ Planning trip with params: {query}")
    try:
        start_time = time.time()

        state: TravelState = {
            "origin": query.origin,
            "destination": query.destination,
            "date": query.date,
            "location": query.location,
            "checkin": query.checkin,
            "checkout": query.checkout,
            "flights": None,
            "hotels": None,
        }

        result = workflow.invoke(state)  # Use .ainvoke if workflow supports async
        duration = time.time() - start_time
        logger.info(f"✅ Trip orchestration complete in {duration:.2f}s")
        return {"trip_plan": result}
    except Exception as e:
        logger.error(f"❌ Trip planning failed: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Trip planning failed")

# ---------------- RAG Setup ---------------- #
index_name = "travel-knowledge"
connector = RAGConnectorFactory.create("pinecone", index_name=index_name)
# LLM for RAG
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

prompt_template = """You are a travel assistant. Use ONLY the context provided to answer the question.
If the answer is not in the context, say "I don't know".

Context:
{context}

Question:
{question}

Answer:"""

prompt = PromptTemplate(input_variables=["context", "question"], template=prompt_template)

@app.post("/travel-knowledge")
async def travel_knowledge(query: RagQuery):
    try:
        retriever = connector.get_retriever(search_kwargs={"k": 3})
        rag_chain = RetrievalQA.from_chain_type(
            llm=llm,
            retriever=retriever,
            chain_type="stuff",
            chain_type_kwargs={"prompt": prompt},
            return_source_documents=True,
        )
        result = rag_chain.invoke(query.question)
        
        # Deduplicate sources
        unique_sources = [
            {"source": src}
            for src in dict.fromkeys(doc.metadata.get("source", "unknown") for doc in result["source_documents"])
        ]

        return {
            "answer": result["result"],
            "sources": unique_sources,
        }
    except Exception as e:
        logger.error(f"❌ RAG query failed: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="RAG query failed")
    
@app.post("/trip-recommendations")
def trip_recommendations(query: TripQuery):
    state = {
        "origin": query.origin,
        "destination": query.destination,
        "date": query.date,
        "checkin": query.checkin,
        "checkout": query.checkout,
        "flights": None,
        "hotels": None,
        "knowledge": [],
        "suggestions": None
    }

    try:
        logger.info("LANGCHAIN_PROJECT =", os.getenv("LANGCHAIN_PROJECT"))
        start_time = time.time()
        final_state = trip_agent.run_trip_agent(state)
        duration = time.time() - start_time
        return {
            "recommendations": final_state,
            "search_time": f"{duration:.2f}s"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Trip recommendations failed: {str(e)}")

@app.post("/mcp-trip-recommendations")
async def mcp_trip_recommendations(query: MCPTripQuery):
    state = query.dict()
    start_time = time.time()
    try:
        result = mcp_agent.run_trip(state)
        duration = time.time() - start_time
        return {
            "recommendations": {
                "flights": result.get("flights"),
                "hotels": result.get("hotels"),
                "knowledge": result.get("knowledge"),
            },
            "mcp_logs": result.get("mcp_logs"),
            "search_time": f"{duration:.2f}s"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Trip planning failed: {str(e)}")

@app.post("/chat-trip")
async def chat_trip(query: ChatTripQuery):
    try:
        logger.info(f"Received query: {query.json() if hasattr(query, 'json') else query}")

        # 1️⃣ Start conversation
        if query.user_input == "__start_conversation__" or not query.state:
            state = ConversationState(
                origin=None,
                destinations=[],
                chat_history=[],
                suggestions={},
                user_input=None,
                step="ask_origin"
            )
            state.chat_history.append({
                "role": "assistant",
                "message": "Hello! Where are you traveling from?"
            })
            logger.info(f"Initialized conversation state: {state}")
            return {"state": state.dict(), "chat_history": state.chat_history}

        # 2️⃣ Continue conversation
        state = ConversationState(**query.state)
        logger.debug(f"Current state before processing user input: {state}")

        if query.user_input:
            state.user_input = query.user_input
            state.chat_history.append({"role": "user", "message": query.user_input})
            logger.info(f"Added user input to state: {query.user_input}")

        # 3️⃣ Invoke workflow
        new_state = await asyncio.wait_for(
            conversation_workflow.ainvoke(state),
            timeout=30
        )
        logger.info(f"New state after workflow: {new_state}")

        # 4️⃣ If trip is completed, fetch recommendations
        if getattr(new_state, "step", None) == "completed":
            try:
                rec_payload = {
                    "origin": new_state.origin,
                    "destinations": new_state.destinations,
                    "date": getattr(new_state, "travel_date", None),
                    "checkin": getattr(new_state, "checkin", None),
                    "checkout": getattr(new_state, "checkout", None),
                }
                logger.info(f"Fetching recommendations with payload: {rec_payload}")
                rec_response = requests.post("http://127.0.0.1:8000/trip-recommendations", json=rec_payload)
                rec_response.raise_for_status()
                rec_data = rec_response.json()
                new_state.suggestions = rec_data
                new_state.chat_history.append({
                    "role": "assistant",
                    "message": "Here are some recommendations for your trip!"
                })
                logger.info(f"Recommendations fetched successfully: {rec_data}")
            except Exception as e:
                logger.error(f"Failed to fetch recommendations: {e}")
                new_state.chat_history.append({
                    "role": "assistant",
                    "message": f"Could not fetch recommendations: {e}"
                })

        return {
            "state": new_state.dict() if hasattr(new_state, "dict") else new_state,
            "chat_history": getattr(new_state, "chat_history", [])
        }

    except Exception as e:
        logger.exception("❌ Conversational trip planning failed")
        raise HTTPException(status_code=500, detail=f"Conversational trip planning failed: {e}")
