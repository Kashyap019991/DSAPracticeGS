import asyncio
from concurrent.futures import ThreadPoolExecutor
from typing import List, Dict, Any
from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from langchain.chains import LLMChain
from pathlib import Path
from langchain.output_parsers import PydanticOutputParser
import os
from pydantic import BaseModel, Field
from trip_planner.logger import get_logger
from dotenv import load_dotenv
from langsmith import traceable

logger = get_logger("flight_agent")
executor = ThreadPoolExecutor()

load_dotenv()

# ---------------- Structured Output ---------------- #
class FlightResult(BaseModel):
    flights: List[Dict[str, Any]] = Field(
        description="List of available flights with airline, price, and timing"
    )

    
# ---------------- Load Prompt ---------------- #
prompt_path = Path(__file__).parent.parent / "prompts" / "flight_prompts.md"
with open(prompt_path, "r", encoding="utf-8") as f:
    prompt_template_text = f.read()

prompt = PromptTemplate(
    input_variables=["origin", "destination", "date"],
    template=prompt_template_text,
)

parser = PydanticOutputParser(pydantic_object=FlightResult)

# ---------------- Lazy Initialization ---------------- #
def get_llm():
    """Create the LLM only when called, so .env is loaded properly."""
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        logger.error("❌ OPENAI_API_KEY is not set in environment.")
        raise RuntimeError("OPENAI_API_KEY missing")
    return ChatOpenAI(model="gpt-4o-mini", temperature=0, api_key=api_key)


def get_flight_chain():
    return LLMChain(llm=get_llm(), prompt=prompt)

@traceable(name="Flight Agent Sync")
# ---------------- Synchronous call ---------------- #
def run_agent(origin: str, destination: str, date: str) -> dict:
    logger.info(f"Running flight agent for {origin} -> {destination} on {date}")
    flight_chain = get_flight_chain()
    raw = flight_chain.run(origin=origin, destination=destination, date=date)

    try:
        result = parser.parse(raw)
        logger.info("✅ Flight agent parsed valid structured response.")
        return result.dict()
    except Exception as e:
        logger.warning(f"⚠️ Flight agent returned non-structured response: {e}")
        return {"raw_response": raw}

@traceable(name="Flight Agent Async")
async def run_agent_async(origin: str, destination: str, date: str) -> FlightResult:
    chain = get_flight_chain()
    raw = await chain.arun(origin=origin, destination=destination, date=date)
    try:
        result = parser.parse(raw)
        logger.info("✅ Flight agent parsed valid structured response.")
        return result  # <-- return FlightResult object, not dict
    except Exception as e:
        logger.warning(f"⚠️ Flight agent returned non-structured response: {e}")
        return FlightResult(flights=[])

