from trip_planner.rag.pinecone_connector import PineconeRAGConnector
# Future: from trip_planner.rag.chroma_connector import ChromaRAGConnector
import os

class RAGConnectorFactory:
    @staticmethod
    def create(connector_type: str, **kwargs):
        connector_type = connector_type.lower()

        if connector_type == "pinecone":
            # Only pass what PineconeRAGConnector expects (likely index_name)
            index_name = kwargs.get("index_name") or os.environ.get("PINECONE_INDEX_NAME")
            if not index_name:
                raise ValueError("Pinecone index_name must be provided either via kwargs or PINECONE_INDEX_NAME env variable")
            return PineconeRAGConnector(index_name=index_name)

        # elif connector_type == "chroma":
        #     return ChromaRAGConnector(**kwargs)

        else:
            raise ValueError(f"Unsupported RAG connector type: {connector_type}")
